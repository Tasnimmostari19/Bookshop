<?php include('server.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>user registration</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="Sr.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>

	<div class="header">
		<h2>Successfully Logedin!!!</h2>
	</div>
	<div class="content">
	  <?php if (isset($_SESSION['success'])):?>
	  <div class=" error success">
	  <h3>
	  <?php echo $_SESSION['success'];
	  unset($_SESSION['success']); 
	  ?>
	</h3>
	</div>
	<?php endif; ?>

	Click here to browse Home Page.<br>
			<a href="ass.html">Home page</a>

			
	 <?php if (isset($_SESSION["username"])):?>
	 <p> Welcome <strong>  <?php echo $_SESSION['username']; ?></strong>  </p>
	 <p><a href="index.php? logout='1'" style="color:red;">Logout</a></p>
	 <?php endif; ?>
	</div>
</body>
</html>
