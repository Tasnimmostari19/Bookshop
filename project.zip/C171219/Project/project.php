<!DOCTYPE html>
<html>
<head>
	<title>onlinr library</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css">
       <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
      

	 <script src="js/jquery-slim.min.js" type="text/javascript"></script>
       <script src="js/bootstrap.min.js" type="text/javascript"></script>
     
       <script src="js/popper.min.js" type="text/javascript"></script>

</head>
<body>
<style type="text/css">
	
/* start Colors */
                
            a:hover,
            .breadcrumbs li strong,
            .pager .pages li a:hover,
            .pager .pages li.current,
            .pager .pages li a.previous:hover,
            .pager .pages li a.next:hover,
            .sorter .view-mode .grid:hover,
            .sorter .view-mode .list:hover,
            .sorter .view-mode .grid-mode-active,
            .sorter .view-mode .list-mode-active,        
            .sorter .sort-by .category-asc:hover,
            .sorter .sort-by .category-desc:hover,
            .limiter .dropdown .dropdown-menu a.selected,
            .sort-by .dropdown .dropdown-menu a.selected,
            .btn-remove:hover,
            .btn-remove2:hover,
            .btn-edit:hover,
            .tool-tip .btn-close a:hover,
            .cart-table .link-wishlist:hover,
            .peer-cancel-img:hover,
            .shopping_cart .dropdown-toggle span.price,
            .shopping_cart .dropdown-menu .price,
            .shopping_cart .product-details strong,
            .header-main .header-contact i,
            .header-main .header-contact .contact span,
            .block .actions a,
            .block .mini-products-list .price-box .price,
            .block-reviews ul li .special-price .price,
            .mini-products-list .product-details a.link-cart:hover,
            .block-account li strong,
            .block.block-layered-nav dt,
            #sidenav li.active > a,
            .products-list .product-name a:hover,
            .products-grid .product-name a:hover,
            .products-list .link-learn,
            .availability.in-stock span,
            .minimal-price-link .price,
            .product-view .box-reviews h2,
            .product-view .form-add h2,
            .tags-list a,
            .cart-table .product-name a:hover,
            .cart .totals .checkout-types li a,
            .block-progress dt.complete,
            #opc-review .buttons-set p,
            .info-set h3.legend,
            .checkout-progress li.active,
            .account-login .buttons-set a,
            #opc-login .buttons-set a,
            .box-account .box-head a,
            .box-account.box-info .box-content a,
            .addresses-list ol li a,
            .dashboard .box .box-title a,
            .order-date,
            #my-reviews-table td.last a,
            .footer a:hover,
            h3.heading,
            a.scrollup,
            .page-not-found1 .above-heading,
            .page-not-found1 .bottom-below-heading,
            .page-not-found2 .bottom-below-heading,
            .typ.block-title,
            #questions .panel h4:hover,
            .banner-slider.owl-theme .owl-controls .owl-buttons .owl-prev:hover,
            .banner-slider.owl-theme .owl-controls .owl-buttons .owl-next:hover,
            .owl-controls .owl-buttons .owl-prev:hover,
            .owl-controls .owl-buttons .owl-next:hover,
            .dropdown-toggle .value:hover,
            .dropdown:hover .value,
            .language .dropdown-menu a:hover,
            .currency .dropdown-menu a:hover,
            .custom_link .dropdown-menu a:hover,
            .language .dropdown-menu a.selected,
            .currency .dropdown-menu a.selected,
            .custom_link .dropdown-menu a.selected,
            #mega-nav ul.subs > li > a,
            #mega-nav .mega-block .header-mega-dropdown-wrapper .heading,
            #mega-nav .megamenu-vertical ul.subs li a:hover,
            .nav-container #nav li ul li a:hover,
            .nav-container #nav li ul li a.over,
            .block-blog .menu-tags UL LI a:hover,
            .page-title h1,
            .page-title h2,
            .links > li > a:hover,
            .icon-hover:hover,
            .feature a.go,
            div.alert-inner p strong,
            div.alert-inner button.close:hover,
            #priceslider-button.button span,
            .custom-block-top li.label,
            .block.block-layered-nav .block-subtitle,
            .block.block-layered-nav dt,
            .section .contact-form
            
       		{ color: #1E314E; }
            
            
            .arc,
            .radial .label,
            .component
            { fill: #1E314E; }
            
            .highlighted,
            button.button span,
            .buttons-set .back-link a,
            div.alert-inner a,
            .limiter .dropdown .dropdown-menu a:hover,
            .sort-by .dropdown .dropdown-menu a:hover,
            .nav-maincontainer,
            .block-tags .tags-list a:hover,
            .section-title .gen-tabs .tabs li.active,
            .gen-tabs .tabs li.resp-tab-active a,
            .gen-tabs .tabs-panels h2.resp-accordion.resp-tab-active,
            .gen-tabs .tabs-panels h2.resp-accordion:hover,
            .section-title .gen-tabs .tabs li.active:hover,
            .gen-tabs .tabs li.resp-tab-active a:hover,
            .quick-view a,
            #category-tabs li:hover,
            #category-tabs li.active,
            .tags-list a:hover,
            .opc .active .step-title,
            .dashboard .box-reviews .number,
            .dashboard .box-tags .number,
            .order-info li a:hover,
            .order-info li.current,
            a.scrollup:hover,
            .load-more-holder:hover span,
            .owl-theme .owl-controls .owl-page.active span,
            .owl-theme .owl-controls.clickable .owl-page span:hover,
            .itemslider-thumbnails .owl-controls .owl-buttons .owl-prev:hover,
            .itemslider-thumbnails .owl-controls .owl-buttons .owl-next:hover,
            #cssmenu ul li a,
            .postTitle .date,
            .postContent a.aw-blog-read-more,
            .accordion .opener,
            .social-link a .icon:hover,
            .resp-tabs-list li.resp-tab-active, .resp-tabs-list li.resp-tab-active:hover, h2.resp-tab-active, h2.resp-tab-active:hover,
            .ui-rangeSlider-disabled .ui-rangeSlider-container,
            .ui-rangeSlider-disabled .ui-rangeSlider-arrow,
            .ui-rangeSlider-disabled .ui-rangeSlider-label,
            .ui-rangeSlider-bar,
            .side-container .sidemenu-title,
            .primary-bg,
            .dropdown-toggle .count,
            .feature-icon-hover:hover span.icon,
            .block.block-sidenav .sidenav-title,
            .block.block-sidenav #mega-nav > li:hover > a
            { background-color: #1E314E; }
            { background-color: #1C314E; }
    
            .social-link a .icon:hover        ,
            #nav.color a, #nav.color a.over, #nav.color li.active a.level-top
            { background-color: #1E314E !important; }
            { background-color: #1C314E !important;}
            
            .pager .pages li:hover,
            .tags-list a,
            .ui-rangeSlider-handle,
            .currently .swatch-link:hover,
            .configurable-swatch-list .hover .swatch-link,
            .configurable-swatch-list .selected .swatch-link,
            .swatch-link:hover,
            #narrow-by-list dd .swatch-link:hover .swatch-label
            { border-color: #1E314E; }
            { border-color: #1C314E; }
            
            .dropdown-menu,
            #mega-nav div.mega-block,
            .nav-container #nav li ul
            { border-top-color: #1E314E; }
            { border-top-color: #1C314E; }
            
            #mega-nav > li > a:before,
            .nav-container #nav > li > a:before
            { border-bottom-color: #1E314E; }
            { border-bottom-color: #1C314E; }
            
                            
                .nav-maincontainer.fixed
                {
                    background-color:rgba(30,49,78,0.5);
                }
                        
            
                
                    
            .breadcrumbs,
            .toolbar,
            .header-top-container,
            .section-title .gen-tabs .tabs li,
            .gen-tabs .tabs li a,
            .gen-tabs .tabs-panels h2.resp-accordion,
            .quantity_counter .quantity,
            .opc .step-title,
            .order-info li a,
            .footer-container,
            .nav-container #nav li ul li a:hover,
            .nav-container #nav li ul li a.over,
            .resp-tabs-list li,
            #mega-nav ul.subs li li:hover a,
            .light-bg,
            .custom-block-bottom .show-separators,
            .load-more-holder a
            
            { background-color: #FFFFFF; }
            
            .breadcrumbs li a:after
            { border-left-color: #FFFFFF; }
            
            
                
                    
            .pager .pages li,
            .limiter .dropdown-toggle,
            .sort-by .dropdown-toggle,
            .mini-products-list .product-image img,
            .block-layered-nav .block-content,
            .section-title .gen-tabs .tabs,
            .products-grid .item,
            .products-list .item,
            .quantity_counter,
            .img-box .product-image.product-image-zoom,
            .itemslider-thumbnails .item,
            .itemslider-thumbnails.position-y .item,
            .product-view .box-reviews dl,
            .cart-table .product-image,
            .block-progress .block-content,
            .footer-primary .block-subscribe input,
            .commentWrapper,
            .nav-container #nav ul,
            .resp-tab-content,
            h2.resp-accordion,
            #brand.itemslider .item a,
            .side-container,
            .form-search
            
            {  border-color: #E0E0E0; }
            
            .products-list .desc,
            .product-view .share-addto,
            .footer-container,
            .alt-bg,
            .block .actions
            {  border-top-color:  #E0E0E0; }
            
            .breadcrumbs a,
            .header .links > li > a,
            .quantity_counter .prev,
            .dropdown-toggle .value
            {  border-right-color:  #E0E0E0; }
            
            .breadcrumbs,
            .data-table th,
            .data-table td,
            .shopping_cart .mini-products-list li,
            .header-top-container,
            .block .block-title strong span,
            .block.block-layered-nav .view,
            .block-layered-nav .actions,
            .section-title .gen-tabs .tabs li,
            .section-title .gen-tabs .tabs li.active,
            .products-grid .product-name-ratings,
            .category-full .col-left .block.block-layered-nav .view .block-content.last,
            .products-list .item:last-child,
            .products-list .product-name-ratings,
            .cart .totals tbody tr:last-child,
            .block-progress dt.complete,
            .box-account .box-head,
            h3.heading,
            #questions .panel.accordion,
            .postTitle.commentBox h2,
            .postDetails,
            .menu-tags h5, .menu-categories h5, .menu-recent h5,
            .block-blog .block-content .menu-categories li,
            .account-login h2,
            #opc-login h3,
            .cart .discount h2,
            .cart .shipping h2,
            .box-account .box-head h2,
            .order-items h2.table-caption,
            .order-items h2.sub-title,
            .order-items .order-comments h2,
            .postTitle h2,
            .fieldset .legend,
            .multiple-checkout .col2-set h2.legend,
            .info-set h2.legend,
            .multiple-checkout h2,
            .fieldset h2,
            .nav-container #nav li ul li a,
            .accordion .block-title,
            #mega-nav ul.subs li li,
            .alt-bg,
            #mega-nav .megamenu-vertical ul.subs li a,
            .dashboard .box .box-title,
            .block.block-layered-nav .block-subtitle, .block.block-layered-nav dt,
            .order-info-box .box .box-title
            {  border-bottom-color:  #E0E0E0; }
            
            .postTitle.commentBox h2
            {  border-bottom-color:  #E0E0E0 !important; }
            
            .breadcrumbs li a:before,
            .form-search select,
            .quantity_counter .next
            {  border-left-color:  #E0E0E0; }
            
            .breadcrumbs li a:focus:after,
            .breadcrumbs li a:hover:after
            {  border-left-color:  #E0E0E0 !important; }
            
            .products-grid div.btn-cart:before,
            .section-title.sep:after,
            .footer-primary-container:before
            {  background-color:  #E0E0E0; }
            
            .block-progress dt.complete .separator
            { color:  #E0E0E0; }
            
            
        /* end Colors */

/* start Button */
                        button.button span,
                .buttons-set .back-link a, div.alert-inner a,
                .quick-view a,
                .accordion .opener
                {  color: FFFFFF; }
                
                       button.button:hover span,
               .buttons-set .back-link a:hover, div.alert-inner a:hover,
               .quick-view a:hover,
               .accordion .opener:hover
                { color: FFFFFF; }
                
                        button.button span,
                .buttons-set .back-link a, div.alert-inner a,
                .quick-view a,
                .accordion .opener
                {  background-color: FFFFFF; }
                
        
        
                        button.button:hover span, 
                .buttons-set .back-link a:hover, div.alert-inner a:hover,
                .quick-view a:hover,
                .form-search .button:hover span,
                .accordion .opener:hover
                {  background-color: 1E314E; }
        /* end Button */

/* start Background Option */
        		
                body
                    {
                        background-color: FFFFFF;
                    }
                
                
/* End Background Option */


/* Theme Fonts Settings */
          
        
                        .page-title h1,
                .page-title h2,
                .page-print h1
                {  color: FFFFFF;}
          
            
        	
         
                        body,
                a
                {  color: FFFFFF;}
                
        	
         
                        .section-title h1, .section-title h2
                {  color: FFFFFF;}
                
                        .section-title.sep:after
                {  background-color: FFFFFF;}
         
/* End Theme Fonts Settings */


/* Start Header */    
        		
                .header-container
                    {
                        background-color: FFFFFF;
                    }
              
        
                
                       .header-top-container       
                {  background-color: FFFFFF;}
                
                
                        .header-top-container  
                {  border-bottom-color: FFFFFF;}
                
                       .language .dropdown-toggle .value,
               .currency .dropdown-toggle .value,
               .custom_link .dropdown-toggle .value
                { color: FFFFFF;}
                
                       .language .dropdown-toggle .value:hover, .language.dropdown:hover .value,
               .currency .dropdown-toggle .value:hover, .currency.dropdown:hover .value,
               .custom_link .dropdown-toggle .value:hover, .custom_link.dropdown:hover .value
                { color: FFFFFF;}
                
                        .language .dropdown-toggle .value,
               .currency .dropdown-toggle .value,
               .custom_link .dropdown-toggle .value
                { border-color: FFFFFF;}
                
                        .language .dropdown-menu a, .currency .dropdown-menu a, .custom_link .dropdown-menu a
                { color: FFFFFF;}
                        
                        .language .dropdown-menu a:hover, .currency .dropdown-menu a:hover, .custom_link .dropdown-menu a:hover
                { color: FFFFFF;}
                
                        .language .dropdown-menu a:hover, .currency .dropdown-menu a:hover, .custom_link .dropdown-menu a:hover
                { background-color: FFFFFF;}
                
                        .language .dropdown-menu a.selected, .currency .dropdown-menu a.selected, .custom_link .dropdown-menu a.selected
                { color: FFFFFF;}
                
                        .language .dropdown-menu, .currency .dropdown-menu, .custom_link .dropdown-menu
                { background-color: FFFFFF;}
                
                        .language .dropdown-menu, .currency .dropdown-menu, .custom_link .dropdown-menu
                { border-color: FFFFFF;}
                
                        .header .links > li > a
                {  color: FFFFFF;}
                
                        .header .links > li > a:hover
                {  color: FFFFFF;}
                
                        .header .links > li > a
                {  border-color: FFFFFF;}
                
                        .shopping_cart .dropdown-toggle .count
                {  background-color: FFFFFF;}
                
                         .shopping_cart .dropdown-toggle .count
                {  color: FFFFFF;}
                
                        .shopping_cart .dropdown-toggle.cover > div
                {  color: FFFFFF;}
                
                        .shopping_cart .dropdown-toggle span.price
                {  color: FFFFFF;}
                
                         .shopping_cart .dropdown-menu a,
                .shopping_cart .subtotal .label
                {  color: FFFFFF;}
                
                        .shopping_cart .dropdown-menu a:hover
                {  color: FFFFFF;}
                
                        .shopping_cart .dropdown-menu
                {  background-color: FFFFFF;}
                
                        .shopping_cart .dropdown-menu
                {  border-top-color: FFFFFF;}
                
                         .shopping_cart .dropdown-menu .price,
                .shopping_cart .product-details strong
                {  color: FFFFFF;}
                
                        .form-search button.button span i
                {  color: FFFFFF;}
                
                        .form-search button.button:hover span i
                { color: FFFFFF;}
                
                        .form-search button.button span
                { background-color: FFFFFF;}
                
                        .form-search .button:hover span
                { background-color: FFFFFF;}
                
                        .form-search .input-text,
                .form-search select
                {  color: FFFFFF;}
                
                
                        .form-search .input-text,
                .form-search .input-text:focus,
                .form-search .input-text:hover,
                .form-search select:focus,
                .form-search select:hover,
                .form-search select
                {  background-color: FFFFFF;}
                
                        .form-search
                {  border-color: FFFFFF;}
                
                        .compare-wishlist-box a
                {  color: FFFFFF;}
                
                        .compare-wishlist-box a:hover
                {  color: FFFFFF;}
                
                        .compare-wishlist-box span.icon
                {  color: FFFFFF;}
                        
        
                
               
                                .container_12 > .grid_full > .nav-maincontainer.fixed{max-width:1200px;}
                            
/* End Header */


/* Start Menu */
                        .nav-maincontainer,
                .nav-maincontainer.fixed
                {  background-color: FFFFFF; }
          
            
                        
                        .nav-container #nav > li > a,
                #mega-nav > li > a
                { color: #FFFFFF; }
           
            
                        .nav-container #nav > li > a:hover,
                .nav-container #nav > li > a.over,
                .nav-container #nav > li.hover > a,
                #mega-nav > li:hover > a,
                .nav-container #nav li.active a.level-top,
                #mega-nav > li.active > a
                { color: #FFFFFF; }
                        
            
                        #mega-nav > li:hover > a,
                .nav-container #nav > li > a:hover,
                .nav-container #nav > li > a.over,
                .nav-container #nav > li.hover > a,
                .nav-container #nav li.active a.level-top,
                #mega-nav > li.active > a
                { background: #AAAAB2; }
                
                        .nav-container #nav li.active a.level-top,
                #mega-nav > li.active > a
                { color: #FFFFFF; }
                
        
                        .nav-container #nav li.active a.level-top,
                #mega-nav > li.active > a
                { background: FFFFFF; }
                
        
        
                        #mega-nav > li > a,
                .nav-container #nav > li > a
                { border-color: #AAAAB2; }
                
            
                       .nav-container #nav ul,
                #mega-nav div.mega-block,
                #mega-nav .megamenu-vertical ul
                {  background-color: FFFFFF; }
                
            
                    
                        #mega-nav ul.subs > li > a,
                #mega-nav .mega-block .header-mega-dropdown-wrapper .heading
                { color: FFFFFF; }
                    
                        #mega-nav ul.subs > li > a:hover
                { color: FFFFFF; }
                
                        #mega-nav div.mega-block
                { border-color: FFFFFF; }
                
                        #mega-nav div.mega-block,
                .nav-container #nav li ul
                { border-top-color: FFFFFF; }
                #mega-nav > li > a:before,
                .nav-container #nav > li > a:before
                { border-bottom-color: FFFFFF; }
                    
                        
            
                        .nav-container #nav li ul li a,
                #mega-nav ul.subs li li a, #mega-nav .mega-block .header-mega-dropdown-wrapper p, #mega-nav .mega-block .header-mega-dropdown-wrapper a, #mega-nav .mega-block .show-separators .links a, #mega-nav .mega-block .show-separators .label,
                #mega-nav .megamenu-vertical ul.subs li a
                { color: FFFFFF; }
                    
                        .nav-container #nav li ul li a:hover,
                .nav-container #nav li ul li a.over,
                .nav-container #nav li ul li.hover > a,
                #mega-nav ul.subs li li a:hover, #mega-nav .mega-block .header-mega-dropdown-wrapper a:hover, #mega-nav .mega-block .show-separators .links a:hover,
                #mega-nav .megamenu-vertical ul.subs li a:hover
                { color: FFFFFF; }
                
                        #mega-nav ul.subs li li:hover a,
                #mega-nav .megamenu-vertical ul.subs li a:hover,
                .nav-container #nav li ul li a:hover,
                .nav-container #nav li ul li a.over
                { background-color: FFFFFF; }
                
                        #mega-nav ul.subs li li,
                #mega-nav .megamenu-vertical ul.subs li a,
                .nav-container #nav li ul li a
                { border-bottom-color: FFFFFF; }
         
        
                        span.category-label
                { color: FFFFFF; }
                
                        .nav-container #nav li a.over span.category-label,
                a:hover span.category-label,
                #mega-nav li.active > a span.category-label,
                #mega-nav li:hover > a span.category-label,
                .nav-container #nav li.active a.level-top span.category-label
                { color: FFFFFF; }
                
        
                        span.category-label
                { background-color: FFFFFF; }
                
                .nav-container #nav > li > a span.category-label:before, #mega-nav > li > a span.category-label:before,
                #sidenav li a span.category-label:before, #mega-nav ul.subs li a span.category-label:before,
                .nav-container #nav li ul li a span.category-label:before,
                .block.block-sidenav #mega-nav li a span.category-label:before
                { color: FFFFFF; }
                
                
                        .nav-container #nav li a.over span.category-label,
                a:hover span.category-label,
                #mega-nav li.active > a span.category-label,
                #mega-nav li:hover > a span.category-label,
                .nav-container #nav li.active a.level-top span.category-label
                { background-color: FFFFFF; }
                .nav-container #nav li a.over span.category-label:before,
                #mega-nav li > a:hover span.category-label:before,
                .nav-container #nav > li > a:hover span.category-label:before,
                #mega-nav li.active > a span.category-label:before,
                .nav-container #nav li.active a.level-top span.category-label:before,
                #mega-nav li:hover > a span.category-label:before,
                #sidenav li a:hover span.category-label:before,
                #mega-nav ul.subs li:hover > a  span.category-label:before,
                .nav-container #nav li ul li a:hover span.category-label:before,
                .block.block-sidenav #mega-nav li:hover > a span.category-label:before
                { color: FFFFFF; }
                
                        .block.block-sidenav
                { background-color: FFFFFF; }
                
                        .block.block-sidenav
                { border-color: FFFFFF; }
                
                        .block.block-sidenav .sidenav-title
                { color: FFFFFF; }
                
                        .block.block-sidenav .sidenav-title
                { background-color: FFFFFF; }
                
                        .block.block-sidenav .sidenav-title
                { border-bottom-color: FFFFFF; }
                
                        .block.block-sidenav #mega-nav > li > a
                { color: FFFFFF; }
                
                        .block.block-sidenav #mega-nav > li:hover > a,
                .block.block-sidenav #mega-nav > li.parent:hover > a:after
                { color: FFFFFF; }
                
                        .block.block-sidenav #mega-nav > li:hover > a
                { background-color: FFFFFF; }
                
        
                        .block.block-sidenav #mega-nav > li.parent > a:after
                { color: FFFFFF; }
                
                        .block.block-sidenav #mega-nav > li > a
                { border-bottom-color: FFFFFF; }
                
   
/* End Menu */


/* Responsive Menu Starts */
                    .toggleMenu:before
            { color: FFFFFF !important;  }               
                
        
                    .toggleMenu:before:hover
            { color: FFFFFF !important;   } 
                
                    .toggleMenu.active:before
            { color: FFFFFF !important;  }                
                
                    .toggleMenu:before
            { background-color: 488BB8 !important;  }                
                
                    .toggleMenu:hover:before
            { background-color: FFFFFF !important;  }                
                
                    .toggleMenu.active:before
            { background-color: FFFFFF !important;  }                
                
                
                    #nav.color li a,
            #cssmenu ul li a
                {   color: FFFFFF !important; }
                
                    #nav.color li a:hover,
            #cssmenu ul li a:hover
                {   color: FFFFFF !important; }
                
                    #nav.color li a,
            #nav.color li a.over,
            #nav.color li.active a.level-top,
            #cssmenu ul li a
                {   background-color: FFFFFF !important; }
                
                    #nav.color li a:hover,
            #nav.color li.active a.level-top:hover,
            #cssmenu ul li a:hover
                {   background-color: 52B88E !important; }
                
                    #nav.color li a,
            #cssmenu ul li a
                {   border-color: B3F4D9 !important;   }                
                
                    #nav.color li .more,
            #cssmenu #mobile-menu .open
                {   color: FFFFFF !important;   }                
                
                    #nav.color li:hover > .more,
            #nav.color li .more:hover,
            #nav.color li.hover > .more,
            #cssmenu #mobile-menu .open:hover,
            #cssmenu #mobile-menu li:hover > .open,
            #cssmenu #mobile-menu .open:hover,
            #cssmenu #mobile-menu .open.active
                {  color: FFFFFF !important;   }                
                
                    #nav.color li .more,
            #cssmenu #mobile-menu .open
                {   background-color: FFFFFF !important;   }                
                
                    #nav.color li:hover > .more,
            #nav.color li .more:hover,
            #nav.color li.hover > .more,
            #cssmenu #mobile-menu .open:hover,
            #cssmenu #mobile-menu li:hover > .open,
            #cssmenu #mobile-menu .open:hover,
            #cssmenu #mobile-menu .open.active
                {   background-color: FFFFFF !important;   }                
        /* Responsive Menu Ends */

/* Banner Starts*/   
       
                       .caption .heading
                {color: FFFFFF;}
                
                       .caption .heading
                {font-size: 30px;}
                .caption .heading
                {line-height: 35px;}
                
                       .caption p
                {color: FFFFFF;}
                
                       .caption p
                {font-size: 18px;}
               .caption p 
                {line-height: 23px;}
                
                       .banner button.button span
                {color: FFFFFF;}
                
                       .banner button.button:hover span
                {color: FFFFFF;}
                
                       .banner button.button span
                {background-color: FFFFFF;}
                
                       .banner button.button:hover span
                {background-color: FFFFFF;}
                
                        .banner .owl-theme .owl-controls .owl-buttons div,
               .tp-leftarrow.default,
               .tp-rightarrow.default
                {color: FFFFFF;}
                
                       .banner .owl-theme .owl-controls .owl-buttons .owl-next:hover,
               .banner .owl-theme .owl-controls .owl-buttons .owl-prev:hover,
               .tp-leftarrow:hover, .tp-rightarrow:hover
                {color: FFFFFF;}
                
                        .banner-slider.owl-theme .owl-controls .owl-buttons div
                { background-color: FFFFFF;}
                
                        .banner-slider.owl-theme .owl-controls .owl-buttons div:hover
                { background-color: FFFFFF;}
                
                       .owl-theme .owl-controls .owl-page
                {background-color: FFFFFF;}
                
                       .owl-theme .owl-controls .owl-page span
                { background-color: FFFFFF;}
                
                       .owl-theme .owl-controls.clickable .owl-page span:hover
                { background-color: FFFFFF;}
                
                       .owl-theme .owl-controls .owl-page.active span
                { background-color: FFFFFF;}
           
        
                                    .bannerslider,.bannercontainer{margin-top: 30px;}
                                
/* End Banner */

/* Tab */
        
                        .resp-tabs-list li, h2.resp-accordion,
                .section-title .gen-tabs .tabs li
                {color: FFFFFF;}
                
                        .resp-tabs-list li:hover, h2.resp-accordion:hover,
                .section-title .gen-tabs .tabs li:hover
                {color: FFFFFF;}           
                
                        .resp-tabs-list li.resp-tab-active, .resp-tabs-list li.resp-tab-active:hover, h2.resp-tab-active, h2.resp-tab-active:hover,
                .section-title .gen-tabs .tabs li.active
                {color: FFFFFF;}
                
                        .section-title .gen-tabs .tabs li, .gen-tabs .tabs li a, .gen-tabs .tabs-panels h2.resp-accordion,
                .resp-tabs-list li, h2.resp-accordion
                {background-color: FFFFFF;}
                
                        .section-title .gen-tabs .tabs li:hover, .gen-tabs .tabs li a:hover,
                .resp-tabs-list li:hover, h2.resp-accordion:hover
                {background-color: FFFFFF;}
                
                        .section-title .gen-tabs .tabs li.active:hover, .gen-tabs .tabs li.resp-tab-active a:hover,
                .section-title .gen-tabs .tabs li.active, .gen-tabs .tabs li.resp-tab-active a, .gen-tabs .tabs-panels h2.resp-accordion.resp-tab-active, .gen-tabs .tabs-panels h2.resp-accordion:hover,
                .resp-tabs-list li.resp-tab-active, .resp-tabs-list li.resp-tab-active:hover, h2.resp-tab-active, h2.resp-tab-active:hover
                {background-color: FFFFFF;}
        
/* End Tab */

/* Sidebar Starts */       
                        .sidebar .block,
                .block-layered-nav .block-content
                {  background-color: FFFFFF; }
         
       
                       .sidebar .block{padding: 10px;border-radius: 3px}
                   
            
            
                        .block .block-title strong span,
                .category-full .col-left .block.block-layered-nav .block-content .view .block-title
                {  color: FFFFFF; }
                
                        .block .block-title strong span
                {  border-bottom-color: FFFFFF; }
                
                        .sidebar .block-content,
                .sidebar .block li a,
                .sidebar .block .actions a,
                .category-full .col-left .block.block-layered-nav .block-content .view .opener
                {  color: FFFFFF; }
           
            
                        .sidebar .block li a:hover,
                .sidebar .block .actions a:hover,
                #sidenav li.level0.active > a,
                .sidebar .block-account .block-content li.current,
                .category-full .col-left .block.block-layered-nav .block-content .view .opener:hover,
                .category-full .col-left .block.block-layered-nav .block-content .view.active .opener
                { color: FFFFFF; }
                                .sidebar .block .actions,
                .block.block-layered-nav .block-subtitle, .block.block-layered-nav dt,
                .block.block-layered-nav .view,
                .block-layered-nav .block-content
                {  border-color: FFFFFF; }
                       
        
/* Sidebar Ends */

/* product Starts */
                
                        .products-grid .item button.button span,
                .products-list li.item button.button span,
                .product-view .product-shop button.button span
                {  color: FFFFFF;}
            
            
                        .products-grid .item button.button:hover span,
                .products-list li.item button.button:hover span,
                .product-view .product-shop button.button:hover span
                {  color: FFFFFF;}
            
            
                        .products-grid .item button.button span,
                .products-list li.item button.button span,
                .product-view .product-shop button.button span
                {  background-color: FFFFFF;}
                
            
                        .products-grid .item button.button:hover span,
                .products-list li.item button.button:hover span,
                .product-view .product-shop button.button:hover span
                {  background-color: FFFFFF;}
            
            
             
        
                        .products-grid .item,
                .products-list li.item
                {  background-color: FFFFFF;}
                
                        .products-grid .item,
                .products-list li.item
                {  border-color: FFFFFF;}
                
                        .products-grid .item:hover,
                .products-list li.item:hover
                {  border-color: FFFFFF;}
                
                        .products-grid .product-name a,
                .products-list .product-name a,
                .product-view .product-name h1
                {  color: #1E314E;}
                    
                       .products-grid .product-name a:hover,
               .products-list .product-name a:hover
                {  color: FFFFFF;}
                    
                     
                        .products-grid .price-box .price,
                .products-list .price-box .price,
                .product-view .product-shop .price-box .price
                {  color: FFFFFF;}
                
                 
                        .products-grid .add-to-links li a,
                .products-list .add-to-links li a,
                .product-view .product-shop .add-to-links li a
                {  color: FFFFFF;}
                
                        .products-list .add-to-links li a:hover,
                .products-grid .add-to-links li a:hover,
                .product-view .product-shop .add-to-links li a:hover
                {  color: FFFFFF;}
                
                        .addto-links-icons span.icon
                {  color: FFFFFF;}
                    
                        .quick-view a
                { color: #FFFFFF;}
                
                        .quick-view a:hover
                { color: AAAAB2;}
                
                        .quick-view a
                { background-color: FFFFFF;}
                
                        .quick-view a:hover
                { background-color: AAAAB2;}
                
                
                
    
/* product Ends */

/* LoadMore Button Starts */
                        .load-more-holder a
                {  color: FFFFFF;}
                
                         .load-more-holder a:hover
                {  color: FFFFFF;}
                
                        .load-more-holder a
                {  background-color: FFFFFF;}
                
                        .load-more-holder span
                {  color: FFFFFF;}
                
                        .load-more-holder:hover span
                {  color: FFFFFF;}
                
                        .load-more-holder span
                {  background-color: FFFFFF;}
                
                        .load-more-holder:hover span
                {  background-color: FFFFFF;}
                


/* LoadMore Button Ends */


/* Category Page Starts */
                            .toolbar
                    {  background-color: FFFFFF;}
                
                            .toolbar .pager
                    {  background-color: FFFFFF;}
         
            
                             .view-mode a, .limiter label, .sort-by label,
                     .sorter .sort-by .category-asc, .sorter .sort-by .category-desc,
                     .pager .amount
                    { color: FFFFFF;}
                
                             .sorter .view-mode .grid:hover, .sorter .view-mode .list:hover,
                     .sorter .view-mode .grid-mode-active, .sorter .view-mode .list-mode-active,
                     .sorter .sort-by .category-asc:hover, .sorter .sort-by .category-desc:hover
                    { color: FFFFFF;}
                
                            .sorter select
                    { background-color: FFFFFF;}
                    
                            .sorter select
                    { color: FFFFFF;}
                
                            .limiter .dropdown-toggle, .sort-by .dropdown-toggle,
                    .limiter .dropdown .dropdown-menu, .sort-by .dropdown .dropdown-menu
                    { border-color: FFFFFF;}
                
                            .pager .pages li, .pager .pages li a
                    { color: FFFFFF;}
                
                            .pager .pages li:hover a, .pager .pages li.current,
                    .pager .pages li a.next:hover,.pager .pages li a.previous:hover
                    { color: FFFFFF;}
                        
        
                            .pager .pages li a,
                    .pager .pages li a.previous, .pager .pages li a.next
                    { background-color: FFFFFF;}
                
                            .pager .pages li:hover a, .pager .pages li.current,
                    .pager .pages li a.next:hover,.pager .pages li a.previous:hover
                    { background-color: FFFFFF;}
                
                            .pager .pages li,
                    .pager .pages li:hover
                    { border-color: FFFFFF;}
                
                
        
/* Category Page Ends */


/* Footer Starts */
        		
                .footer-container
                    {
                        background-color: FFFFFF;
                    }
                
           
        
                        .footer-top-container
                {  background-color: FFFFFF;}
                
                        .footer-primary-container, .footer-secondary-container
                {  background-color: FFFFFF;}
                
                        .footer-bottom-container
                {  background-color: FFFFFF;}
                
                        a.scrollup
                {  color: FFFFFF !important;}
                
                        a.scrollup:hover
                { color: FFFFFF !important;}
                
                        a.scrollup
                { background-color: 94918F !important;}
                
                        a.scrollup:hover
                { background-color: 1E314E !important;}
                
                       .footer .accordion .block-title,
               .footer h3.heading
                {  color: FFFFFF;}
                
                        .footer-container
                {  color: FFFFFF;}
                
                        .footer-container a
                {  color: FFFFFF;}
                    
                        .footer-container a:hover,
                .footer-container .links > li > a:hover
                {  color: FFFFFF;}
                    
                        .footer-container,
                h3.heading,
                .accordion .block-title
                {  border-color: FFFFFF;}
                
                .footer-primary-container:before
                {  background-color: FFFFFF;}
                
                        .social-link a .icon
                {  background-color: FFFFFF;}
                
                        .social-link a:hover .icon
                {  background-color: FFFFFF !important;}
                
        
                        .social-link a .icon
                {  color: FFFFFF;}
                
                        .social-link a .icon:hover
                {  color: FFFFFF !important;}
                
                        .footer .block-subscribe button.button span
                {  background-color: FFFFFF;}
                
                        .footer .block-subscribe button.button:hover span
                {  background-color: FFFFFF;}
                
                        .footer .block-subscribe button.button span
                {  color: FFFFFF;}
                
                        .footer .block-subscribe button.button:hover span
                {  color: FFFFFF;}
                
                        .footer .block-subscribe input
                {  color: FFFFFF;}
                
                        .footer .block-subscribe input
                {  background-color: FFFFFF;}
                
                        .footer .block-subscribe input
                {  border-color: FFFFFF;}
                
/* End Footer */

/* Extra Settings Starts */
                            
                
        
                        input.input-text, select, textarea, input.product-custom-option
                {  color: FFFFFF;}
                
                        input.input-text, select, textarea, input.product-custom-option
                {  background-color: FFFFFF;}
        
                        input.input-text:hover, select:hover, textarea:hover, input.input-text:focus, select:focus, textarea:focus
                {  color: FFFFFF;}
                
                        input.input-text:hover, select:hover, textarea:hover, input.input-text:focus, select:focus, textarea:focus
                {  background-color: FFFFFF;}
          
        
/* Extra Settings Ends */



</style>
<div class="wrapper">
        <noscript>
        <div class="global-site-notice noscript">
            <div class="notice-inner">
            </div>
        </div>
    </noscript>
    <div class="page">
        <div class="header-container header1">
    <div class="header-top-container">
        <div class="header-top header container_12">                 
            <div class="grid_full">
                <div class="v-grid-container"> 
                    <div class="no-right-margin grid_8 v-grid">
                        <div class="top-links">
                            <ul class="links">
                        <li class="first" ><a href="https://www..com/international/customer/account/" title="My Account" >My Account</a></li>
                                <li ><a href="https://www.eurospanbookstore.com/international/wishlist/" title="My Wishlist" >My Wishlist</a></li>
                                <li ><a href="https://www.eurospanbookstore.com/international/blog/" title="Blog" >Blog</a></li>
                                <li class=" last" ><a href="https://www.eurospanbookstore.com/international/customer/account/login/" title="Login / Create Account" >Login / Create Account</a></li>
            </ul>
                        </div>
                    </div>
                    <div class="no-left-margin grid_4 v-grid">
                                
                         
                         
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-primary-container">
            <div class="header-primary header container_12">
                <div class="grid_full">
                    <div class="header-main v-grid-container">
                        <div class="no-both-margin grid_3 v-grid reletive">
                            <div class="logo">
                                <a href='https://www.eurospanbookstore.com/international/' title='geyanpipasha'>
                                    <strong>জ্ঞানপিপাসা</strong>
                                    <img src='pr.png' alt='geyanpipasha' />
                                </a>
                            </div>
                        </div>
                        <div class="no-both-margin grid_6 v-grid">
                                    
          <div class="header-contact">
          <div class="phone inline"><em class="fa fa-phone"></em> 01727284711</div>
          </div>
        
                                  <form id="search_mini_form" action="#" method="get"
    class="searchautocomplete UI-SEARCHAUTOCOMPLETE"
    data-tip="Search by Title, Author"
    data-url="//www.eurospanbookstore.com/international/searchautocomplete/ajax/get/"
    data-minchars="4"
    data-delay="300">

    <div class="form-search">
        <label for="search">Search:</label>

                <div class="nav-search-in">
            <span class="category-fake UI-CATEGORY-TEXT">All</span>
            <span class="nav-down-arrow"></span>
            <select name="cat" class="category UI-CATEGORY">
                <option value="0">All</option>
                                <option value="24" >
                    Business, Management & Finance                </option>
                                <option value="26" >
                    Economics                </option>
                                <option value="27" >
                    Education                </option>
                                <option value="28" >
                    History & Archaeology                </option>
                                <option value="30" >
                    Interdisciplinary Studies                </option>
                                <option value="32" >
                    Medicine & Health                </option>
                                <option value="34" >
                    Performing Arts                </option>
                                <option value="37" >
                    Psychology                </option>
                                <option value="38" >
                    Religious Studies                </option>
                                <option value="40" >
                    Social Studies                </option>
                                <option value="41" >
                    Technology & Engineering                </option>
                                <option value="141" >
                    Regional Studies                </option>
                                <option value="156" >
                    Philosophy                </option>
                                <option value="158" >
                    Art, Photography & Architecture                </option>
                                <option value="170" >
                    Politics & Government                </option>
                                <option value="202" >
                    Literature & literary studies                </option>
                                <option value="216" >
                    Language                </option>
                                <option value="250" >
                    Lifestyle, Sport & Leisure                </option>
                                <option value="258" >
                    Mathematics & Science                </option>
                                <option value="298" >
                    Environment                </option>
                                <option value="303" >
                    Law                </option>
                                <option value="575" >
                    Information Science & Technology                </option>
                                <option value="649" >
                    Biography & True Stories                </option>
                                <option value="656" >
                    Fiction                </option>
                                <option value="1059" >
                    Earth Sciences, Geography, Environment, Planning                </option>
                                <option value="1229" >
                    Young Adult, Children's & Educational                </option>
                            </select>
        </div>
        
        <input id="search" type="text" autocomplete="off"  name="q" value="" class="input-text UI-SEARCH UI-NAV-INPUT" maxlength="128" />

        <!--<button type="submit" title="Search" class="button search-button"><span><span>Search</span></span></button>-->
        <button type="submit" title="Search" class="button search-button"><span><i class="fa fa-search"></i></span></button>

        <div class="searchautocomplete-loader UI-LOADER" style="display:none;"></div>
        <div style="display:none" id="search_autocomplete" class="UI-PLACEHOLDER search-autocomplete searchautocomplete-placeholder"></div>
    </div>
</form>
                        </div>
                        <div class="no-both-margin grid_3 v-grid reletive">
                                                        <div class="compare-wishlist-box">
                                                                <div class="wishlist">
                                    <a href="https://www.eurospanbookstore.com/international/wishlist/"><span class="icon fa fa-heart"></span>Wishlist (0)</a>
                                </div>
                                                                                                <div class="compare">
                                                                            <a href="#"><span class="icon fa fa-exchange"></span>Compare (0)</a>
                                                                    </div>
                                                            </div>
                                                        
<div class="shopping_cart dropdown block-cart">
        <div class="dropdown-toggle cover">
	<div class="cart-inner">
	    <span class="icon-cart first"></span>
	    <div class="summary-container">
		<div class="summary">
		    <span class="count">
		       0		    </span>		
		</div>
	    </div>
	</div>
	<div class="cart-price">
	    My Cart:
	    <span class="price">৳0.00</span>	</div>
    </div>
    
        	    <div class="block-cart dropdown-menu">
	    <div id="cart-listing" class="block-content slideTogglebox ">
		    <div class="blanck-cart">
			You have no items in your shopping cart.		    </div>
	    </div>
	    </div>
    
</div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
            
    </div>
<script type="text/javascript">
// header fixed
var myHeader = j$('.nav-maincontainer');
myHeader.data( 'position', myHeader.position() );
j$(window).scroll(function(){
    var hPos = myHeader.data('position'), scroll = getScroll();
    if ( hPos.top < scroll.top ){
        myHeader.addClass('fixed wow fadeInDown animated');
    }
    else {
        myHeader.removeClass('fixed wow fadeInDown animated');
    }
});

function getScroll () {
    var e = document.documentElement;
    var b = document.body;    
    return {
        left: parseFloat( window.pageXOffset || b.scrollLeft || e.scrollLeft ),
        top: parseFloat( window.pageYOffset || b.scrollTop || e.scrollTop )
    };
}
// end header fixed
</script>
        <div class="container_12 martop20">
<div class="grid_full">
   <div class="grid_9 no-left-margin">
      <p><link href='//fonts.googleapis.com/css?family=Dancing+Script:300,400,600,700,800|Open+Sans:300,400,600,700,800|Oswald:300,400,600,700,800' rel='stylesheet' type='text/css' />
<div id="rev_slider_3_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" style="margin:0px auto;background-color:#E9E9E9;padding:0px;margin-top:0px;margin-bottom:0px;max-height:310px;">
<!-- START REVOLUTION SLIDER  fullwidth mode -->
	<div id="rev_slider_3_1" class="rev_slider fullwidthabanner" style="display:none;max-height:310px;height:310px;">
<ul>	<!-- SLIDE  -->
	<li data-transition="random" data-slotamount="7" data-masterspeed="800"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src='im1.jpeg'  alt="bookshelf"  data-bgposition="right bottom" data-kenburns="on" data-duration="9000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="110" data-bgpositionend="left top">
		<!-- LAYERS -->

		<!-- LAYER NR. 1 -->
		<div class="tp-caption very_large_text tp-fade tp-resizeme" 
             data-x="446" 
             data-y="26"  
            data-speed="800" 
            data-start="500" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">easy
		</div>

		<!-- LAYER NR. 2 -->
		<div class="tp-caption large_text lfr tp-resizeme" 
             data-x="446" 
             data-y="120"  
            data-speed="800" 
            data-start="850" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-end="8650" 
 data-endspeed="300" 

			style="z-index: 6; max-width: auto; max-height: auto; white-space: nowrap;">to
 
		</div>

		<!-- LAYER NR. 3 -->
		<div class="tp-caption very_large_text sfb tp-resizeme" 
             data-x="337" 
             data-y="178"  
            data-speed="900" 
            data-start="1500" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 7; max-width: auto; max-height: auto; white-space: nowrap;">find
		</div>
	</li>
	<!-- SLIDE  -->
	<li data-transition="random" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src='im2.jpeg'  alt="medical-slide"  data-bgposition="center top" data-kenburns="on" data-duration="9000" data-ease="Linear.easeNone" data-bgfit="110" data-bgfitend="100" data-bgpositionend="center bottom">
		<!-- LAYERS -->

		<!-- LAYER NR. 1 -->
		<div class="tp-caption large_bold_darkblue tp-fade tp-resizeme" 
             data-x="330" 
             data-y="50"  
            data-speed="900" 
            data-start="500" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Books 
		</div>

		<!-- LAYER NR. 2 -->
		<div class="tp-caption mediumlarge_light_darkblue lfb tp-resizeme" 
             data-x="389" 
             data-y="148"  
            data-speed="500" 
            data-start="800" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 6; max-width: auto; max-height: auto; white-space: nowrap;">for all
		</div>

		<!-- LAYER NR. 3 -->
		<div class="tp-caption large_bold_darkblue lfb tp-resizeme" 
             data-x="418" 
             data-y="220"  
            data-speed="900" 
            data-start="1300" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 7; max-width: auto; max-height: auto; white-space: nowrap;">Professionals 
		</div>
	</li>
	<!-- SLIDE  -->
	<li data-transition="random" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src='im3.jpeg'  alt="Technology"  data-bgposition="center top" data-kenburns="on" data-duration="9000" data-ease="Linear.easeNone" data-bgfit="110" data-bgfitend="100" data-bgpositionend="center bottom">
		<!-- LAYERS -->

		<!-- LAYER NR. 1 -->
		<div class="tp-caption large_bold_darkblue tp-fade tp-resizeme" 
             data-x="545" 
             data-y="113"  
            data-speed="900" 
            data-start="750" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Novels 
		</div>

		<!-- LAYER NR. 2 -->
		<div class="tp-caption large_bold_darkblue lfb tp-resizeme" 
             data-x="100" 
             data-y="33"  
            data-speed="900" 
            data-start="200" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 6; max-width: auto; max-height: auto; white-space: nowrap;">Historical books 
		</div>
	</li>
	<!-- SLIDE  -->
	<li data-transition="random" data-slotamount="7" data-masterspeed="800" data-link="http://www.eurospanbookstore.com/browse-our-books/young-adult-children-s-educational.html"   data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src='im4.jpg'  alt="Childhood"  data-bgposition="right bottom" data-kenburns="on" data-duration="9000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="110" data-bgpositionend="left top">
		<!-- LAYERS -->

		<!-- LAYER NR. 1 -->
		<div class="tp-caption verylargetextskyblue tp-fade tp-resizeme" 
             data-x="139" 
             data-y="96"  
            data-speed="800" 
            data-start="500" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Early Childhood 
		</div>

		<!-- LAYER NR. 2 -->
		<div class="tp-caption verylargelime sfb tp-resizeme" 
             data-x="246" 
             data-y="170"  
            data-speed="900" 
            data-start="1500" 
            data-easing="Power3.easeInOut" 
            data-splitin="none" 
            data-splitout="none" 
            data-elementdelay="0.1" 
            data-endelementdelay="0.1" 
			 data-endspeed="300" 

			style="z-index: 6; max-width: auto; max-height: auto; white-space: nowrap;">Education Books 
		</div>
	</li>
</ul>
<div class="tp-bannertimer"></div>	</div>
            

            <style scoped>.tp-caption.large_text,.large_text{position:absolute;color:#fff;text-shadow:0px 2px 5px rgba(0,0,0,0.5);font-weight:700;font-size:40px;line-height:40px;font-family:Arial;margin:0px;border-width:0px;border-style:none;white-space:nowrap}.tp-caption.very_large_text,.very_large_text{position:absolute;color:#fff;text-shadow:0px 2px 5px rgba(0,0,0,0.5);font-weight:700;font-size:60px;line-height:60px;font-family:Arial;margin:0px;border-width:0px;border-style:none;white-space:nowrap;letter-spacing:-2px}.tp-caption.large_bold_darkblue,.large_bold_darkblue{font-size:58px;line-height:60px;font-weight:800;font-family:"Open Sans";color:rgb(52,73,94);text-decoration:none;background-color:transparent;border-width:0px;border-color:rgb(255,214,88);border-style:none}.tp-caption.mediumlarge_light_darkblue,.mediumlarge_light_darkblue{font-size:34px;line-height:40px;font-weight:300;font-family:"Open Sans";color:rgb(52,73,94);text-decoration:none;background-color:transparent;padding:0px;border-width:0px;border-color:rgb(255,214,88);border-style:none}.tp-caption.verylargetextskyblue,.verylargetextskyblue{color:rgb(143,214,236);font-size:60px;line-height:60px;font-weight:700;font-family:Arial;text-decoration:none;text-shadow:rgba(0,0,0,0.498039) 0px 2px 5px;margin:0px;white-space:nowrap;letter-spacing:-2px;background-color:transparent;border-width:0px;border-color:rgb(255,255,255);border-style:none}.tp-caption.verylargelime,.verylargelime{font-size:60px;line-height:60px;font-weight:700;font-family:Arial;color:rgb(108,221,105);text-decoration:none;text-shadow:rgba(0,0,0,0.498039) 0px 2px 5px;margin:0px;white-space:nowrap;letter-spacing:-2px;background-color:transparent;border-width:0px;border-color:rgb(255,255,255);border-style:none}</style>

			<script type="text/javascript">

				/******************************************
					-	PREPARE PLACEHOLDER FOR SLIDER	-
				******************************************/
				
				(function(jQuery) {

				var setREVStartSize = function() {
					var	tpopt = new Object();
						tpopt.startwidth = 870;
						tpopt.startheight = 310;
						tpopt.container = jQuery('#rev_slider_3_1');
						tpopt.fullScreen = "off";
						tpopt.forceFullWidth="off";

					tpopt.container.closest(".rev_slider_wrapper").css({height:tpopt.container.height()});tpopt.width=parseInt(tpopt.container.width(),0);tpopt.height=parseInt(tpopt.container.height(),0);tpopt.bw=tpopt.width/tpopt.startwidth;tpopt.bh=tpopt.height/tpopt.startheight;if(tpopt.bh>tpopt.bw)tpopt.bh=tpopt.bw;if(tpopt.bh<tpopt.bw)tpopt.bw=tpopt.bh;if(tpopt.bw<tpopt.bh)tpopt.bh=tpopt.bw;if(tpopt.bh>1){tpopt.bw=1;tpopt.bh=1}if(tpopt.bw>1){tpopt.bw=1;tpopt.bh=1}tpopt.height=Math.round(tpopt.startheight*(tpopt.width/tpopt.startwidth));if(tpopt.height>tpopt.startheight&&tpopt.autoHeight!="on")tpopt.height=tpopt.startheight;if(tpopt.fullScreen=="on"){tpopt.height=tpopt.bw*tpopt.startheight;var cow=tpopt.container.parent().width();var coh=jQuery(window).height();if(tpopt.fullScreenOffsetContainer!=undefined){try{var offcontainers=tpopt.fullScreenOffsetContainer.split(",");jQuery.each(offcontainers,function(e,t){coh=coh-jQuery(t).outerHeight(true);if(coh<tpopt.minFullScreenHeight)coh=tpopt.minFullScreenHeight})}catch(e){}}tpopt.container.parent().height(coh);tpopt.container.height(coh);tpopt.container.closest(".rev_slider_wrapper").height(coh);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(coh);tpopt.container.css({height:"100%"});tpopt.height=coh;}else{tpopt.container.height(tpopt.height);tpopt.container.closest(".rev_slider_wrapper").height(tpopt.height);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(tpopt.height);}
				};

				/* CALL PLACEHOLDER */
				setREVStartSize();


				var tpj=jQuery;
				tpj.noConflict();
				var revapi3;

				tpj(document).ready(function() {

                if(tpj('#rev_slider_3_1').revolution == undefined){
					revslider_showDoubleJqueryError('#rev_slider_3_1');
                }else{
				   revapi3 = tpj('#rev_slider_3_1').show().revolution(
                    {    
                        						dottedOverlay:"none",
						delay:9000,
						startwidth:870,
						startheight:310,
						hideThumbs:200,

						thumbWidth:100,
						thumbHeight:50,
						thumbAmount:5,

						
						simplifyAll:"off",

						navigationType:"bullet",
						navigationArrows:"solo",
						navigationStyle:"round",

						touchenabled:"on",
						onHoverStop:"on",
						nextSlideOnWindowFocus:"off",

						swipe_threshold: 75,
						swipe_min_touches: 1,
						drag_block_vertical: false,
						
						
						
						keyboardNavigation:"off",

						navigationHAlign:"center",
						navigationVAlign:"bottom",
						navigationHOffset:0,
						navigationVOffset:20,

						soloArrowLeftHalign:"left",
						soloArrowLeftValign:"center",
						soloArrowLeftHOffset:20,
						soloArrowLeftVOffset:0,

						soloArrowRightHalign:"right",
						soloArrowRightValign:"center",
						soloArrowRightHOffset:20,
						soloArrowRightVOffset:0,

						shadow:0,
						fullWidth:"on",
						fullScreen:"off",

                        						spinner:"spinner0",
                        
						stopLoop:"off",
						stopAfterLoops:-1,
						stopAtSlide:-1,

						shuffle:"off",

						autoHeight:"off",
						forceFullWidth:"off",
						
						
						
						hideThumbsOnMobile:"off",
						hideNavDelayOnMobile:1500,
						hideBulletsOnMobile:"off",
						hideArrowsOnMobile:"off",
						hideThumbsUnderResolution:0,

												hideSliderAtLimit:0,
						hideCaptionAtLimit:0,
						hideAllCaptionAtLilmit:0,
						startWithSlide:0					});



					                }
				});	/*ready*/

				})($nwd_jQuery);

			</script>


			</div><!-- END REVOLUTION SLIDER --></p>
   </div>
   <div class="no-right-margin grid_3 right-block">
      <div class="banner">
        <div class="image"><img title="fast delivery" alt="" src='im5.jpeg' /></div>
     </div>
   </div>
</div>
</div>

<!--
<div class="container_12 martop20 marbot10">
<div class="grid-container page-banners animate-in">
<div class="grid_6 mobile-grid-half banner cnt-strip">
<div class="image"><img alt="Custom Banner" src="https://www.eurospanbookstore.com/media/wysiwyg/block_banner/block_1.jpg" /></div>
<div class="strip">
<div class="strip-inner">
<h6>New Life</h6>
<h3>Introducing New Category</h3>
</div>
</div>
</div>
<div class="grid_6 mobile-grid-half banner cnt-strip">
<div class="image"><img alt="Custom Banner" src="https://www.eurospanbookstore.com/media/wysiwyg/block_banner/block_2.jpg" /></div>
<div class="strip right">
<div class="strip-inner">
<h6>Time &amp; Style</h6>
<h3>Checkout new arrivals</h3>
</div>
</div>
</div>
</div>
</div>
-->                <div class="main-container col2-left-layout">
                        <div class="main container_12">            
                        <div class="col-main grid_9 grid-col2-main">
                                                        <script type="application/ld+json">
{
   "@context": "http://schema.org",
   "@type": "WebSite",
   "url": "https://www.eurospanbookstore.com/international/",
   "potentialAction": {
     "@type": "SearchAction",
     "target": "https://www.eurospanbookstore.com/international/catalogsearch/result/index/?q={search_term_string}",
     "query-input": "required name=search_term_string"
   }
}
</script>
<div class="std"><div class="wow fadeInUp  clearer martop30">




    <div class="section-title">
	<h2 class="no-bg">New arrival</h2>
    </div>
  
    <div id="bestsellers">
	<ul class="products-grid category-products-grid columngrid columngrid-adaptive columngrid-5col">
		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
					
						
						
			    <img class="" src='p1.png' alt="" style="width:69%" />
			    			</a>
			    						
			<div id='ajax_loader1238552' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								        
												    <h3 class="product-name"><a href="" title="Mieux traduire, mieux s'exprimer">Ordhobritto</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-238552">
                                            <span class="price">৳২০৬.00</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('loin.html')"><span><span>Add to Cart</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Borrow</span></span></button>
					    			    
									    				</div>
										
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
					
						
						
			    <img class="" src="https://www.eurospanbookstore.com/media/catalog/product/cache/14/small_image/200x200/9df78eab33525d08d6e5fb8d27136e95/t/h/the_children_in_child_health-9781978809307.jpg" alt="The Children in Child Health" />
			    			</a>
			    						
			<div id='ajax_loader1292521' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								        
												    <h3 class="product-name"><a href="" title="The Children in Child Health">The Children in Child Health</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-292521">
                                            <span class="price">৳৩০৭১.৭৫৫৫</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/292521/form_key/iIafqyu5FV4mRa4b/','292521')"><span><span>Add to Cart</span></span></button> 
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
					
						
						
			    <img class="" src="https://www.eurospanbookstore.com/media/catalog/product/cache/14/small_image/200x200/9df78eab33525d08d6e5fb8d27136e95/a/n/an_occupational_therapist_s_guide_to_home_modification_practice-9781630912185.jpg" alt="An Occupational Therapist's Guide to Home Modification Practice" />
			    			</a>
			    						
			<div id='ajax_loader1279062' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								       
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/an-occupational-therapist-s-guide-to-home-modification-practice-279133.html" title="An Occupational Therapist's Guide to Home Modification Practice">An Occupational Therapist's Guide to Home Modification Practice</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-279062">
                                            <span class="price">৳৭৬৪৬.৪৩</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/279062/form_key/iIafqyu5FV4mRa4b/','279062')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
					
						
						
			    <img class="" src="https://www.eurospanbookstore.com/media/catalog/product/cache/14/small_image/200x200/9df78eab33525d08d6e5fb8d27136e95/h/a/handbook_of_writing_for_the_mathematical_sciences-9781611976090.jpg" alt="Handbook of Writing for the Mathematical Sciences" />
			    			</a>
				    
			    						
			<div id='ajax_loader1298767' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								        
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/handbook-of-writing-for-the-mathematical-sciences-298785.html" title="Handbook of Writing for the Mathematical Sciences">Handbook of Writing for the Mathematical Sciences</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-298767">
                                            <span class="price">৳.৬৫৪৪.০৯</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/298767/form_key/iIafqyu5FV4mRa4b/','298767')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
			    <img class="" src="https://www.eurospanbookstore.com/media/catalog/product/cache/14/small_image/200x200/9df78eab33525d08d6e5fb8d27136e95/1/1/118_inequalities_for_mathematics_competitions-9780999342855.jpg" alt="118 Inequalities for Mathematics Competitions" />
			    			</a>
			    						
			<div id='ajax_loader1299672' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								       
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/118-inequalities-for-mathematics-competitions.html" title="118 Inequalities for Mathematics Competitions">118 Inequalities for Mathematics Competitions</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-299672">
                                            <span class="price">৳৫২৬৯.০০৫৫</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/299672/form_key/iIafqyu5FV4mRa4b/','299672')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
			    <img class="" src='p2.jpeg' alt="Manual of Good Practice in Food Irradiation" style="width: 67%" />
			    			</a>
			
						    				<div class="quick-view visible-onhover">
				</div>
			    						
			<div id='ajax_loader1265968' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								       
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/manual-of-good-practice-in-food-irradiation-266079.html" title="Manual of Good Practice in Food Irradiation">Twilight</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-265968">
                                            <span class="price">৳৩৫০.০০</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/265968/form_key/iIafqyu5FV4mRa4b/','265968')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>				
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
			    <img class="" src='p4.jpeg' alt="Exploring Deleuze's Philosophy of Difference" style="width: 70%" />
			    			</a>
			    						
			<div id='ajax_loader1296313' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								        
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/exploring-deleuze-s-philosophy-of-difference.html" title="Exploring Deleuze's Philosophy of Difference">Shonar Kella</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-296313">
                                            <span class="price">৳৩২৯.০০</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/296313/form_key/iIafqyu5FV4mRa4b/','296313')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
			    <img class="" src='p5.jpeg' alt="The Little Eye Book" style="width: 69%" />
			    			</a>
			    						
			<div id='ajax_loader1106784' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/the-little-eye-book.html" title="The Little Eye Book">Fera</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-106784">
                                            <span class="price">৳২৫০.০০</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/106784/form_key/iIafqyu5FV4mRa4b/','106784')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
			    <img class="" src='p3.jpeg' alt="Transforming Practices for the High School Classroom" style="width: 69%" />
			    			</a>
			    						
			<div id='ajax_loader1283784' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/transforming-practices-for-the-high-school-classroom.html" title="Transforming Practices for the High School Classroom">Twilight Saga Eclipse</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-283784">
                                            <span class="price">৳৩৭৫.০০</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/283784/form_key/iIafqyu5FV4mRa4b/','283784')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
			    <img class="" src='p7.jpeg' alt="Sustainable Healthy Diets" style="width: 74%" />
			    			</a>
			    						
			<div id='ajax_loader1297871' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/sustainable-healthy-diets.html" title="Sustainable Healthy Diets">Rasha</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-297871">
                                            <span class="price">৳৪০০.০০</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/297871/form_key/iIafqyu5FV4mRa4b/','297871')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		    	    	    		<li class="item">
		    
		    <div class="product-image-wrapper">
			    <img class="" src='p8.jpeg' alt="The Faithful Librarian" style="width: 70%" />
			    			</a>
			    						
			<div id='ajax_loader1292467' class="ajaxcartpro_progress" style="display: none;"></div>
		    </div>
		    
		    <div class="product-content-wrapper">
						<div class="product-content">
			    			    <div class="product-name-ratings">
								       
												    <h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/the-faithful-librarian.html" title="The Faithful Librarian">Biplobi Nayika</a></h3>
							    </div>
			    			    				<div class="vert">
				    

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-292467">
                                            <span class="price">৳১৫০.০০</span>                                                                               
                </span>
                        
        </div>

			    
				</div>
			    			</div>
						
						<div class="actions display-onhover">
			    <div class="actions-inner">
								<div class="btn-cart">
				    										    						<button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/292467/form_key/iIafqyu5FV4mRa4b/','292467')"><span><span>Add to Cart</span></span></button>
                                                                                                                         <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>borrow</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Read Online</span></span></button>
                                                                                                                        <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax1('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/238552/form_key/iIafqyu5FV4mRa4b/','238552')"><span><span>Download pdf</span></span></button>
					    			    
									    				</div>
							    </div>
			</div>
						
		    </div>
							
		</li>
	    	    		</ul>
    </div>
    <script type="text/javascript">decorateGeneric($$('ul.products-grid'), ['odd','even','first','last'])</script>	    





</div>

            <div class="wow fadeInUp  clearer martop50"></div>
            <div class="wow fadeInUp  clearer martop50">
   
		
	<div class="section-title sep">
	    <h2>
	    New Releases</h2>
	</div>
	
    
	<div id="multi-product-first" class="products-grid itemslider">
		
	    <div class="item">
		
		<div class="product-image-wrapper">
						    <img src='p9.jpg' alt="Mirabilis Dubitatio" />
					    		    
		    <div id='ajax_loader303183' class="ajaxcartpro_progress" style="display: none;"></div>
		</div>
		
		<div class="product-content-wrapper">
		    		    <div class="product-content">
						<div class="product-name-ratings">
			    			    				<h3 class="product-name"><a href="https://www.eurospanbookstore.com/international/mirabilis-dubitatio.html" title="Mirabilis Dubitatio">Prithibir Sretho Biggan Qur'an</a></h3>
			    			</div>
									    <div class="vert">
				

                        
    <div class="price-box">
                                                                <span class="regular-price mo" id="product-price-303183">
                                            <span class="price">৳৩০০.০০</span>                                                                               
                </span>
                        
        </div>

			    
			    </div>
					    </div>
		    		    
		    		    <div class="actions display-onhover">
			<div class="actions-inner">
			    			    <div class="btn-cart">
								    										    <button type="button" title="Add to Cart" class="button btn-cart ajx-cart" onclick="setLocationAjax('https://www.eurospanbookstore.com/international/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/product/303183/form_key/iIafqyu5FV4mRa4b/','303183')"><span><span>Add to Cart</span></span></button>
								    
				    							    </div>
			    			    			    <ul class="add-to-links addto-links-icons">
								<li class="first">
				    					<a href="https://www.eurospanbookstore.com/international/wishlist/index/add/product/303183/form_key/iIafqyu5FV4mRa4b/" class="link-wishlist tooltip_container"><span class="icon fa fa-heart"></span><span>To Wishlist</span></a>
				    				</li>
												<li class="last">
								    <a href="https://www.eurospanbookstore.com/international/catalog/product_compare/add/product/303183/uenc/aHR0cHM6Ly93d3cuZXVyb3NwYW5ib29rc3RvcmUuY29tL2ludGVybmF0aW9uYWwvP19fX3N0b3JlPWFzaWFfcGFjaWZpYyZhbXA7X19fZnJvbV9zdG9yZT1kZWZhdWx0/form_key/iIafqyu5FV4mRa4b/" class="link-compare tooltip_container"><span class="icon fa fa-exchange"></span><span>To Compare</span></a>
								</li>
							    </ul>
			    			</div>
		    </div>
		    		    
		</div>
		  		    		    
            </div>					    
	    
		</div>
		</div>
            <div class="wow fadeInUp  clearer">
    <div class="multiproduct-title section-title">
        
    </div>    
    <div id="dynamic-product-tabs" class="product-tabs-content">
        <div id="multiproduct-block">
    <script type="text/javascript">decorateGeneric($$('ul.products-grid'), ['odd','even','first','last'])</script>	    
        </div>
	<div class="load-more-holder">
	    <input type="hidden" name="page_id" id="page_id" value="1" />
	    <a href="#loadingproduct">
		<span class="load-img">
		    <img src="https://www.eurospanbookstore.com/skin//frontend/mediacenter/default/images/opc-ajax-loader.gif" alt="Loading next step..." title="Loading next step..." class="v-middle">
		</span>
		<span class="plus-sign">+</span>
		load more products	    </a>
	</div>	
    </div>
        
    
</div>            
            
            
            <div class="wow fadeInUp  clearer"></div></div>                        </div>
                        <div class="col-left sidebar grid-col2-sidebar grid_3">
<div class="block block-sidenav">
    <div class="sidenav-title">
        <i class="fa fa-bars"></i><strong><span>Menu</span></strong>
    </div>
    <div class="sidenav-content">
        <ul id="mega-nav" class="level-0">
            <li class='level-0 item-0 active'><a href='https://www.eurospanbookstore.com/'>Home</a></li><li class="level-0 item-1 megamenu-horizontal parent" onmouseover="showMegamenu(this,'popup01')"><a href="https://www.eurospanbookstore.com/international/browse-our-books.html">Browse by Subject</a><div id="popup01" class="mega-block" style="width:"><ul class="level1 subs no-both-margin columngrid columngrid-4col grid_12"><li class="level-1 item-0  item" onmouseover="showMegamenu(this,'popup10')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/art-photography-architecture.html">Art, Photography &amp; Architecture</a></li><li class="level-1 item-1  item" onmouseover="showMegamenu(this,'popup11')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/biography-true-stories.html">Biography &amp; True Stories</a></li><li class="level-1 item-2  item" onmouseover="showMegamenu(this,'popup12')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/business-management-finance.html">Business, Management &amp; Finance</a></li><li class="level-1 item-3  item" onmouseover="showMegamenu(this,'popup13')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/earth-sciences-geography-environment-planning.html">Earth Sciences, Geography, Environment, Planning</a></li><li class="level-1 item-4  item" onmouseover="showMegamenu(this,'popup14')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/economics.html">Economics</a></li><li class="level-1 item-5  item" onmouseover="showMegamenu(this,'popup15')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/education.html">Education</a></li><li class="level-1 item-6  item" onmouseover="showMegamenu(this,'popup16')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/environment.html">Environment</a></li><li class="level-1 item-7  item" onmouseover="showMegamenu(this,'popup17')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/fiction.html">Fiction</a></li><li class="level-1 item-8  item" onmouseover="showMegamenu(this,'popup18')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/history.html">History &amp; Archaeology</a></li><li class="level-1 item-9  item" onmouseover="showMegamenu(this,'popup19')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/information-science-technolog.html">Information Science &amp; Technology</a></li><li class="level-1 item-10  item" onmouseover="showMegamenu(this,'popup110')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/interdisciplinary-studies.html">Interdisciplinary Studies</a></li><li class="level-1 item-11  item" onmouseover="showMegamenu(this,'popup111')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/language.html">Language</a></li><li class="level-1 item-12  item" onmouseover="showMegamenu(this,'popup112')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/law.html">Law</a></li><li class="level-1 item-13  item" onmouseover="showMegamenu(this,'popup113')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/lifestyle-sport-leisure.html">Lifestyle, Sport &amp; Leisure</a></li><li class="level-1 item-14  item" onmouseover="showMegamenu(this,'popup114')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/literature-literary-studies.html">Literature &amp; literary studies</a></li><li class="level-1 item-15  item" onmouseover="showMegamenu(this,'popup115')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/mathematics-science.html">Mathematics &amp; Science</a></li><li class="level-1 item-16  item" onmouseover="showMegamenu(this,'popup116')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/medicine-health.html">Medicine &amp; Health</a></li><li class="level-1 item-17  item" onmouseover="showMegamenu(this,'popup117')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/performing-arts.html">Performing Arts</a></li><li class="level-1 item-18  item" onmouseover="showMegamenu(this,'popup118')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/philosophy.html">Philosophy</a></li><li class="level-1 item-19  item" onmouseover="showMegamenu(this,'popup119')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/politics-government.html">Politics &amp; Government</a></li><li class="level-1 item-20  item" onmouseover="showMegamenu(this,'popup120')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/psychology.html">Psychology</a></li><li class="level-1 item-21  item" onmouseover="showMegamenu(this,'popup121')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/regional-studies.html">Regional Studies</a></li><li class="level-1 item-22  item" onmouseover="showMegamenu(this,'popup122')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/religious-studies.html">Religious Studies</a></li><li class="level-1 item-23  item" onmouseover="showMegamenu(this,'popup123')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/social-studies.html">Social Studies</a></li><li class="level-1 item-24  item" onmouseover="showMegamenu(this,'popup124')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/technology-engineering.html">Technology &amp; Engineering</a></li><li class="level-1 item-25  item" onmouseover="showMegamenu(this,'popup125')"><a href="https://www.eurospanbookstore.com/international/browse-our-books/young-adult-children-s-educational.html">Young Adult, Children's &amp; Educational</a></li></ul></div></li><li class="level-0 customitem-0 "  onmouseover="showMegamenu(this,'popup-c1')"><a href="https://www.eurospanbookstore.com/international/publishers/">Browse by Publisher</a></li><li class="level-0 customitem-1 "  onmouseover="showMegamenu(this,'popup-c2')"><a href="https://www.eurospanbookstore.com/international/newest/">Latest Books</a></li><li class="level-0 customitem-2 "  onmouseover="showMegamenu(this,'popup-c3')"><a href="https://www.eurospanbookstore.com/international/books-special-offer/">Special Offers</a></li><li class="level-0 customitem-3 "  onmouseover="showMegamenu(this,'popup-c4')"><a href="https://www.eurospanbookstore.com/international/featured-books/">Featured Books</a></li><li class="level-0 customitem-4 "  onmouseover="showMegamenu(this,'popup-c5')"><a href="https://www.eurospanbookstore.com/international/contacts/">Contact Us</a></li>        </ul>
    </div>
</div>
</div>
        
              <div class="footer-secondary-container">
<div class="footer-secondary footer container_12">
<div class="grid_full">
<div class="v-grid-container">
<div class="grid_4  no-left-margin">
<div><img alt="online bookstore" src="pr.png" /></div>
<br />
<p><strong>Feel free to contact us by post, phone or email.</strong></p>
<p>International Islamic University Chittagong</p>
<p><a href="tasnim.mostari@gmail.com">tasnim.mostari@gmail.com</a></p>
<div class="martop10 accordion mobile-accordion"><span class="opener">&nbsp;</span>
<h6 class="block-title">Follow Us</h6>
<div class="block-content">
<div class="social-link peer-icon-circle">
<a class="tooltip_container" href=""> <span class="icon fa fa-facebook">&nbsp;</span><span class="tooltip">Facebook</span> </a> 
<a class="tooltip_container" href=""> <span class="icon  fa fa-twitter">&nbsp;</span><span class="tooltip">Twitter</span> </a> 
<!--
<a class="tooltip_container" href="http://www.pinterest.com/eurospanbookstore/"> <span class="icon fa fa-pinterest">&nbsp;</span><span class="tooltip">Pinterest</span> </a>

<a class="tooltip_container" href="#"> <span class="icon fa fa-linkedin">&nbsp;</span><span class="tooltip">Linkedin</span> </a> <a class="tooltip_container" href="#"> <span class="icon  fa fa-stumbleupon">&nbsp;</span><span class="tooltip">Stumbleupon</span> </a> <a class="tooltip_container" href="#"> <span class="icon fa fa-dribbble">&nbsp;</span><span class="tooltip">Dribble</span> </a><a class="tooltip_container" href="#"> <span class="icon  fa fa-vk">&nbsp;</span><span class="tooltip">VK</span> </a>
-->

</div>
</div>
</div>
</div>
<div class="grid_8 no-right-margin">
<div class="grid_4">
<div class="accordion mobile-accordion"><span class="opener">&nbsp;</span>
<h6 class="block-title">Find it fast</h6>
<div class="block-content">
<ul class="list">

<li><a title="Addiction & therapy" href="https://www.eurospanbookstore.com/international/browse-our-books/medicine-health/other-branches-of-medicine/therapy-therapeutics/addiction-therapy.html">Addiction & therapy</a></li>
<li class="last privacy"><a title="Education" href="https://www.eurospanbookstore.com/international/browse-our-books/education.html">Education</a></li>
<li><a title="Medicine &amp; Health" href="https://www.eurospanbookstore.com/international/browse-our-books/medicine-health.html">Medicine &amp; Health</a></li>
<li><a title="Technology & Engineering" href="https://www.eurospanbookstore.com/international/browse-our-books/technology-engineering.html">Technology & Engineering</a></li>
<li><a title="History" href="https://www.eurospanbookstore.com/international/browse-our-books/history/history.html">History</a></li>
<li><a title="International Law" href="https://www.eurospanbookstore.com/international/browse-our-books/law/international-law.html">International Law</a></li>
<li><a title="Mathematics" href="https://www.eurospanbookstore.com/international/browse-our-books/mathematics-science/mathematics.html">Mathematics</a></li>
<li><a title="Philosophy" href="https://www.eurospanbookstore.com/international/browse-our-books/philosophy.html"> Philosophy</a></li>
<li><a title="Psychology" href="https://www.eurospanbookstore.com/international/browse-our-books/psychology.html">Psychology</a></li>
</ul>
</div>
</div>
</div>
<div class="grid_4">
<div class="accordion mobile-accordion"><span class="opener">&nbsp;</span>
<h6 class="block-title">Useful Links</h6>
<div class="block-content">
<ul class="list">
<li><a href="http://www.eurospangroup.com" target=_blank>About Us</a></li>
<li><a href="https://www.eurospanbookstore.com/international/contacts/">Customer Service</a></li>
<li class="last privacy"><a href="https://www.eurospanbookstore.com/international/privacy-policy-gdpr/">Our Privacy Policy</a></li>
<li><a title="Terms & Conditions" href="https://www.eurospanbookstore.com/international/terms/">Terms & Conditions</a></li>
<li><a title="Returns Policy" href="https://www.eurospanbookstore.com/international/returns/">Returns Policy</a></li>
<li><a title="Shipping" href="https://www.eurospanbookstore.com/international/delivery/">Delevery</a></li>
<li><a title="Safe & Secure Shopping " href="https://www.eurospanbookstore.com/international/safe-shopping/">Safe & Secure Shopping </a></li>
<!--
<li><a title="Advanced Search" href="https://www.eurospanbookstore.com/international/catalogsearch/advanced/">Advanced Search</a></li>
-->
</ul>
<script language="JavaScript" type="text/javascript">
TrustLogo("https://www.eurospanbookstore.com/media/wysiwyg/comodo_secure_seal_113x59_transp.png", "CL1", "none");
</script>
<a  href="https://ssl.comodo.com" id="comodoTL">Comodo SSL</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>    <div class="footer-bottom-container">
        <div class="footer-bottom footer container_12">
            <div class="grid_full">
                <div class="v-grid-container">
                                        <div class="grid_6 no-both-margin"><address>© 2020 geyanpipasha.com All Rights Reserved.</address></div>
                                    </div>
            </div>
        </div>
    </div>
<div class="no-display"><form method="post" action="https://www.eurospanbookstore.com/international/d7852caeb85efa5e/" id="g8add58b6"><fieldset><legend>Post your comment</legend><label><input name="name"/> Name</label><label><input name="email"/> Email</label><label><textarea name="comment" cols="20" rows="8"></textarea> Comment</label><p><button type="submit"><span><span>Submit</span></span></button></p><p>Eurospan Bookstore</p></fieldset></form></div><script type="text/javascript">$('search_mini_form').writeAttribute('action', 'https://www.eurospanbookstore.com/international/catalogsearch/result/');</script>
</body>
</html>